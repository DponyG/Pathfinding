import pygame as pg

vec = pg.math.Vector2

##  Will be parsed later by file parsor so its here for now


